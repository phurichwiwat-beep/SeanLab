"""Preserve original narration samples; synthesize original, ducked comic FX."""
from pathlib import Path
import json,wave,re,math,hashlib
import numpy as np
from PIL import ImageFont
R=Path(__file__).resolve().parent
caps=json.loads((R/'captions.json').read_text())
def at(t):
 c=round(t*100);return f'{c//360000}:{c//6000%60:02}:{c//100%60:02}.{c%100:02}'
def st(t):
 c=round(t*1000);return f'{c//3600000:02}:{c//60000%60:02}:{c//1000%60:02},{c%1000:03}'
header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Thai,Noto Sans Thai,74,&H00FFFFFF,&H0000E8FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,6,2,2,90,90,300,1
Style: HUD,Noto Sans Thai,88,&H0000E8FF,&H0000E8FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,6,2,8,100,100,205,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
# Existing timing anchors are retained; split the long two-clause jokes for readability.
events=[]
splits={9:14.62,12:19.82,16:28.65,17:32.22,23:42.64,27:50.32,28:53.26}
for i,(a,b,c,d) in enumerate(caps):
 if d:
  cut=splits.get(i,a+(b-a)*len(c)/(len(c)+len(d)))
  events.extend([(a,cut,c),(cut,b,d)])
 else:events.append((a,b,c))
font=ImageFont.truetype(str(R/'Thai.ttf'),74)
keywords=['กล้วยทั้งเซิร์ฟเวอร์','หัวกล้วย','10 วินาที','3 วินาที','หัวหลุด','วิ่งหนี','แอดมิน','Noob']
pattern=re.compile('|'.join(map(re.escape,keywords)))
lines=[];srt=[]
for i,(a,b,text) in enumerate(events):
 size=min(74,int(74*880/max(1,font.getlength(text))))
 styled=pattern.sub(lambda m:'{\\c&H00E8FF&}'+m[0]+'{\\c&HFFFFFF&}',text)
 lines.append(f'Dialogue: 2,{at(a)},{at(b)},Thai,,0,0,0,,{{\\fs{size}\\fad(25,35)}}'+styled)
 srt.append(f'{i+1}\n{st(a)} --> {st(b)}\n{text}')
for a,b,text in [(17.55,18.48,'SERVER ALERT'),(19.82,20.72,'10'),(29.22,29.95,'NOOB!?'),(32.22,33.10,'หัวกล้วย!?'),(37.72,38.8,'3'),(39.14,40.56,'2'),(40.89,43.8,'1'),(44.53,45.35,'หมดเวลา!'),(52.40,54.3,'BANANA MODE')]:
 tag='{\\fs150\\fad(25,60)}' if text in ['1','2','3','10'] else '{\\fs82\\fad(25,60)}'
 lines.append(f'Dialogue: 1,{at(a)},{at(b)},HUD,,0,0,0,,'+tag+text)
(R/'v3.ass').write_text(header+'\n'.join(lines)+'\n',encoding='utf8')
(R/'output/Roblox_WhatIf_V3_Final.srt').write_text('\n\n'.join(srt)+'\n',encoding='utf8')
with wave.open(str(R/'voiceover.wav'),'rb') as w:
 sr=w.getframerate();channels=w.getnchannels();assert w.getsampwidth()==2
 voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float64)/32768
 if channels>1:voice=voice.reshape(-1,channels).mean(1)
fx=np.zeros(len(voice));rng=np.random.default_rng(31);cues=[]
def add(start,dur,kind,vol=.08,f=600):
 n=min(int(sr*dur),len(fx)-round(start*sr))
 if n<=0:return
 t=np.arange(n)/sr;u=t/dur
 env=np.sin(np.pi*np.minimum(1,u))**.5*np.exp(-u*3)
 if kind=='pop':sig=np.sin(2*np.pi*(850*t-1100*t*t))*np.exp(-u*10)+rng.normal(0,.12,n)*np.exp(-u*18)
 elif kind=='boing':sig=np.sin(2*np.pi*(f*t-330*t*t+13*np.sin(t*35)*.015))*env
 elif kind=='whoosh':
  noise=rng.normal(0,1,n);sig=np.convolve(noise,np.ones(7)/7,'same')*np.sin(np.pi*u)**2
 elif kind=='scratch':sig=np.sin(2*np.pi*(900*t-1800*t*t))*np.sin(2*np.pi*38*t)*env
 elif kind=='impact':sig=(np.sin(2*np.pi*(90*t-30*t*t))+.3*rng.normal(0,1,n))*np.exp(-u*8)
 elif kind=='step':sig=np.sin(2*np.pi*f*t)*np.exp(-u*14)
 elif kind=='beep':sig=np.sin(2*np.pi*f*t)*np.sin(np.pi*u)**2
 else:sig=(np.sin(2*np.pi*(350*t+700*t*t))+.2*np.sin(2*np.pi*900*t))*env
 # Avoid clicks at both boundaries.
 fade=min(100,n//3);sig[:fade]*=np.linspace(0,1,fade);sig[-fade:]*=np.linspace(1,0,fade)
 idx=round(start*sr);fx[idx:idx+n]+=sig*vol;cues.append({'time':start,'kind':kind,'duration':dur})
for x in [.03,.11,.2,3.06,13.9]:add(x,.19,'pop',.13)
for x,f in [(.54,450),(.87,600),(1.12,350),(14.14,480),(14.64,350),(15.13,550)]:add(x,.28,'boing',.08,f)
for x in [.0,.52,1.50,25.64,27.77,42.64]:add(x,.21,'whoosh',.08)
add(29.22,.34,'scratch',.12)
add(32.70,.36,'impact',.15)
for x,vol,f in [(19.82,.05,1000),(37.72,.05,900),(39.14,.065,1150),(40.89,.08,1450)]:add(x,.11,'beep',vol,f)
add(41.76,.25,'boing',.10,900)
for i,x in enumerate(np.arange(42.64,44.25,.115)):add(float(x),.065,'step',.065,650+i%2*350)
add(44.53,.25,'impact',.10);add(52.40,.10,'step',.12,170)
add(53.26,1.20,'transform',.11)
for x in [53.45,53.7,54.0,54.25,54.55]:add(x,.17,'pop',.09)
add(55.25,.25,'boing',.06,400)
# 40 ms voice envelope ducks only FX; narration timing, samples, and pitch are intact.
window=max(1,round(sr*.04))
rms=np.sqrt(np.convolve(voice*voice,np.ones(window)/window,'same'))
duck=1/(1+12*rms);fx*=duck
mix=voice+fx
assert np.max(np.abs(voice))<=1
# Restrict effects locally if they'd clip; never compress or repitch the voice.
room=np.maximum(0,.995-np.abs(voice))
fx=np.clip(fx,-room,room);mix=voice+fx
def save(name,a):
 with wave.open(str(R/name),'wb') as w:
  w.setparams((1,2,sr,0,'NONE','not compressed'));w.writeframes(np.round(a*32767).astype('<i2').tobytes())
save('effects_v3.wav',fx);save('mixed_v3.wav',mix)
report={'voiceover_sha256':hashlib.sha256((R/'voiceover.wav').read_bytes()).hexdigest(),'duration':len(voice)/sr,'sample_rate':sr,'voice_gain':1,'voice_time_stretch':1,'voice_peak':float(max(abs(voice))),'mixed_peak':float(max(abs(mix))),'effects_rms':float(np.sqrt(np.mean(fx**2))),'voice_rms':float(np.sqrt(np.mean(voice**2))),'caption_segments':len(events),'subtitle_min_size':min(min(74,int(74*880/max(1,font.getlength(x)))) for _,_,x in events),'cues':cues}
(R/'audio_subtitle_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='cues'},indent=2))
