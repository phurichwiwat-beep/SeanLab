"""Validate the actual exported video and its retained source assets."""
from pathlib import Path
import subprocess,json,re,wave,hashlib,sys
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(R/'check_assets_v3.py')],check=True)
assets=json.loads((R/'asset_integrity_report.json').read_text())
assert assets['status']=='passed'
video=R/'output/Roblox_WhatIf_V3_Final.mp4'
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]))
v=next(s for s in meta['streams'] if s['codec_type']=='video')
a=next(s for s in meta['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'])==(1080,1920),v
assert v['avg_frame_rate']=='30/1',v
assert int(v['nb_frames'])==1713,v
assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p'
assert a['codec_name']=='aac'
assert abs(float(meta['format']['duration'])-57.090958)<.04
decoded=subprocess.run(['ffmpeg','-hide_banner','-v','info','-threads','2','-filter_threads','2','-i',str(video),'-vf','blackdetect=d=0.03:pix_th=0.025:pic_th=0.98','-an','-progress','pipe:1','-nostats','-f','null','-'],capture_output=True,text=True,check=True)
assert 'black_start:' not in decoded.stderr,decoded.stderr
assert int(re.findall(r'^frame=(\d+)$',decoded.stdout,re.M)[-1])==1713
(R/'output/decode_check.log').write_text(decoded.stderr+'\n'+decoded.stdout)
for fr in sorted(set(range(1,1714,2))|set(range(2,93,2))):
 p=R/'frames_v3'/f'frame_{fr:04d}.png'
 with Image.open(p) as im:assert im.size==(720,1280);im.verify()
report=json.loads((R/'audio_subtitle_report.json').read_text())
assert hashlib.sha256((R/'voiceover.wav').read_bytes()).hexdigest()==report['voiceover_sha256']
with wave.open(str(R/'mixed_v3.wav'),'rb') as w:
 sr=w.getframerate();mixed=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
assert abs(len(mixed)/sr-57.090958)<1/sr
assert max(abs(mixed))<.995
pcm=subprocess.check_output(['ffmpeg','-v','error','-i',str(video),'-map','0:a:0','-ac','1','-ar',str(sr),'-f','s16le','pipe:1'])
audio=np.frombuffer(pcm,dtype='<i2').astype(float)/32768
n=min(len(audio),len(mixed));corr=float(np.corrcoef(audio[:n],mixed[:n])[0,1])
assert corr>.98,('Audio synchronization/correlation',corr)
assert report['effects_rms']<report['voice_rms']*.5
thumbs=R/'output/qc_frames';thumbs.mkdir(exist_ok=True)
subprocess.run(['ffmpeg','-y','-v','error','-threads','2','-filter_threads','2','-i',str(video),'-vf',"select='not(mod(n,30))',scale=180:320",'-fps_mode','vfr',str(thumbs/'second_%02d.jpg')],check=True)
images=sorted(thumbs.glob('second_*.jpg'))
for sheet in range((len(images)+14)//15):
 batch=images[sheet*15:sheet*15+15]
 canvas=Image.new('RGB',(900,3*344),'#15151c');draw=ImageDraw.Draw(canvas)
 for j,p in enumerate(batch):
  x=j%5*180;y=j//5*344
  with Image.open(p) as im:canvas.paste(im,(x,y))
  draw.text((x+8,y+322),f'{sheet*15+j:02d}s',fill='white')
 canvas.save(R/f'output/contact_sheet_{sheet+1}.jpg',quality=92)
result={'status':'passed','video':video.name,'width':1080,'height':1920,'fps':30,'decoded_frames':1713,'duration_seconds':float(meta['format']['duration']),'source_pngs_verified':903,'native_hook_frames':92,'black_frames_detected':False,'decode_errors':False,'original_mesh_objects_preserved':assets['original_mesh_objects_preserved'],'original_materials_preserved':assets['original_materials_preserved'],'original_caption_text_preserved':True,'original_voiceover_sha256':report['voiceover_sha256'],'exported_audio_mix_correlation':corr,'mixed_audio_peak':float(max(abs(mixed))),'caption_segments':report['caption_segments'],'contact_sheets':(len(images)+14)//15,'render_method':'720x1280 Cycles; first 3.067 seconds at native 30 FPS; quake frames preserved; other shots at 15 source FPS with interpolation inside shots; 1080x1920 30 FPS export','visual_review':'Pending manual contact-sheet and key-shot inspection.'}
(R/'output/quality_report.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
