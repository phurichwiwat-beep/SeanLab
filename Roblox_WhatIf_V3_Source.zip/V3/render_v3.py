"""Resume-safe CPU rendering; run with the project's official bpy Python."""
from pathlib import Path
import bpy,sys,time,json,os
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'Roblox_WhatIf_V3.blend'))
s=bpy.context.scene
s.render.resolution_x=720;s.render.resolution_y=1280;s.render.resolution_percentage=100
s.cycles.samples=2;s.cycles.use_denoising=True;s.cycles.denoiser='OPENIMAGEDENOISE'
s.cycles.denoising_prefilter='FAST';s.cycles.denoising_quality='FAST'
s.render.threads_mode='FIXED';s.render.threads=int(os.environ.get('V3_THREADS','5'))
s.render.use_persistent_data=True
s.render.image_settings.compression=15
preview='--preview' in sys.argv
frames=[1,9,25,53,82,112,409,451,586,842,880,970,1263,1301,1573,1605,1639,1699] if preview else sorted(set(range(1,1714,2))|set(range(2,93,2)))
if '--benchmark' in sys.argv:frames=[880,882,884]
if '--frames' in sys.argv:frames=[int(x) for x in sys.argv[sys.argv.index('--frames')+1].split(',')]
out=R/('previews' if preview or '--benchmark' in sys.argv else 'frames_v3');out.mkdir(exist_ok=True)
if preview:s.render.resolution_x=360;s.render.resolution_y=640
start=time.monotonic();n=0
progress_name='patch_progress' if '--frames' in sys.argv and not preview else 'progress'
for fr in frames:
 target=out/f'frame_{fr:04d}.png'
 if target.exists() and target.stat().st_size>1000 and '--force' not in sys.argv:continue
 s.frame_set(fr);s.render.filepath=str(target)
 tick=time.monotonic();bpy.ops.render.render(write_still=True);n+=1
 state={'last_frame':fr,'rendered_this_run':n,'total_source_frames':len(frames),'elapsed_seconds':round(time.monotonic()-start,2),'last_frame_seconds':round(time.monotonic()-tick,2),'done':False}
 tmp=out/(progress_name+'.tmp');tmp.write_text(json.dumps(state));tmp.replace(out/(progress_name+'.json'))
 print('V3_FRAME',fr,'SECONDS',state['last_frame_seconds'],flush=True)
if n:
 state['done']=True;(out/(progress_name+'.json')).write_text(json.dumps(state))
print('V3_RENDER_COMPLETE',flush=True)
