# Full six-scene animation. All artwork is actual Blender geometry.
import bpy,math,random,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent
base=(R/'base_scene.py').read_text().split('# Frame-specific rig animation:')[0]
exec(compile(base,str(R/'base_scene.py'),'exec'))
R=Path(__file__).resolve().parent
DURATION=57.090958; FPS=30; END=math.ceil(DURATION*FPS)
scene=bpy.context.scene
# Helpers reuse the approved material and avatar definitions.
def clone_head(src,name):
 dst=empty(name)
 def copykids(old,new):
  for c in old.children:
   o=c.copy();o.animation_data_clear();bpy.context.collection.objects.link(o);o.parent=new;copykids(c,o)
 copykids(src,dst);return dst
loose=clone_head(headroot,'HERO_HEAD_PROP')
runlegs=[]
for q in [-1,1]:
 leg=empty('Tiny running leg',(q*.20,0,-.37),loose);runlegs.append(leg)
 cube('Tiny black leg',(0,0,-.20),(.12,.14,.36),black,.025,leg)
 cube('Tiny red sneaker',(0,-.08,-.40),(.23,.36,.14),red,.035,leg)
# Curved banana mesh, with its own face and end caps.
def banana(parent,name,size=1,glasses=False,feet=False):
 ob=empty(name,parent=parent);ob.scale=(size,)*3;verts=[];faces=[];N=21;K=10
 for i in range(N):
  u=i/(N-1);a=-1.2+2.4*u;r=.035+.19*math.sin(math.pi*u)**.65
  center=Vector((.28-.65*math.cos(a),0,.65*math.sin(a)))
  tangent=Vector((.65*math.sin(a),0,.65*math.cos(a))).normalized();normal=Vector((tangent.z,0,-tangent.x))
  for k in range(K):
   b=2*math.pi*k/K;v=center+normal*(r*math.cos(b))+Vector((0,r*math.sin(b),0));verts.append(tuple(v))
 for i in range(N-1):
  for k in range(K):faces.append((i*K+k,i*K+(k+1)%K,(i+1)*K+(k+1)%K,(i+1)*K+k))
 faces.extend([tuple(range(K-1,-1,-1)),tuple((N-1)*K+k for k in range(K))])
 mesh=bpy.data.meshes.new('Curved yellow peel');mesh.from_pydata(verts,[],faces);mesh.materials.append(yellow);mesh.update()
 o=bpy.data.objects.new('Banana geometry',mesh);bpy.context.collection.objects.link(o);o.parent=ob
 for p in mesh.polygons:p.use_smooth=True
 for a in [-1.2,1.2]:cube('Banana brown tip',(.28-.65*math.cos(a),0,.65*math.sin(a)),(.09,.10,.12),wood,.025,ob)
 for q in [-1,1]:
  cube('Banana eye',(-.32+q*.105,-.19,.11),(.065,.035,.085) if not glasses else (.21,.065,.14),black,.01,ob)
 if glasses:cube('Banana glasses bridge',(-.32,-.22,.13),(.08,.04,.045),black,.005,ob)
 cu=bpy.data.curves.new('Banana smile','CURVE');cu.dimensions='3D';cu.bevel_depth=.014;cu.bevel_resolution=2;sp=cu.splines.new('POLY');sp.points.add(12)
 for i,p in enumerate(sp.points):
  a=math.pi+math.pi*i/12;p.co=(-.32+.14*math.cos(a),-.195,-.04+.08*math.sin(a),1)
 o=bpy.data.objects.new('Banana grin',cu);bpy.context.collection.objects.link(o);o.parent=ob;o.data.materials.append(black)
 return ob
banana_hat=banana(None,'HERO_BANANA_HEAD')
banana_people=[]
for i,(x,y) in enumerate([(0,0),(-2,2),(2,3),(-2.5,6),(2.3,7),(-1.6,11),(1.5,13),(0,8),(-2,17),(2,20)]):
 rt=empty('BANANA_CITIZEN_'+str(i),(x,y,1.45));bn=banana(rt,'Whole banana',1.8,i==0)
 for q in [-1,1]:
  rod('Banana stick leg',(q*.22,0,-.9),(q*.22,0,-1.25),.07,navy,rt)
  cube('Banana sneaker',(q*.22,-.08,-1.30),(.30,.46,.20),red if i==0 else blue,.045,rt)
  rod('Banana arm',(q*.42,0,-.1),(q*.65,-.04,-.4),.055,navy,rt)
 banana_people.append(rt)
admin=empty('ADMIN_ROOT',(0,8,0));al,aa,ah,at=avatar(admin,'Admin',False)
for o in at.children:
 if o.name.startswith('Jacket') and o.type=='MESH':o.data.materials.clear();o.data.materials.append(black)
for arm in aa:
 for o in arm.children:
  if o.name.startswith('Sleeve'):o.data.materials.clear();o.data.materials.append(black)
label=txt('ADMIN badge','ADMIN',(0,0,0),.26,white);label.parent=at;label.location=(0,-.346,.05)
console=empty('BANANA_CONSOLE',(0,6.8,0))
cube('Console pedestal',(0,0,.62),(1.5,1.1,1.15),navy,.12,console)
cube('Console top',(0,0,1.22),(1.85,1.4,.16),white,.10,console)
bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=1);button=bpy.context.object;button.name='BIG_RED_BUTTON';button.parent=console;button.location=(0,0,1.36);button.scale=(.50,.45,.16);button.data.materials.append(red)
label=txt('Banana button label','BANANA MODE',(0,0,0),.18,yellow);label.parent=console;label.location=(0,-.571,.72)
# Extra runaway-head speed streaks and transformation confetti are 3D meshes.
streaks=[]
for i in range(7):streaks.append(cube('Runaway speed streak',(0,0,0),(.035,.6+i*.08,.035),white,.01))
confetti=[]
for i in range(48):
 o=cube('Banana party confetti',(0,0,0),(.07,.13,.02),[yellow,pink,teal,lilac][i%4],0);confetti.append(o)
# Utility: write compact object animation tracks without using any UI operators.
anim=set()
def key(o,loc=None,rot=None,scale=None,fr=1):
 if loc is not None:o.location=loc;o.keyframe_insert('location',frame=fr)
 if rot is not None:o.rotation_euler=rot;o.keyframe_insert('rotation_euler',frame=fr)
 if scale is not None:
  o.scale=(scale,)*3 if isinstance(scale,(int,float)) else scale;o.keyframe_insert('scale',frame=fr)
 anim.add(o)
def smooth(a,b,x):
 u=max(0,min(1,x));u=u*u*(3-2*u);return a+(b-a)*u
def mix(a,b,u):return tuple(a[i]+(b[i]-a[i])*max(0,min(1,u)) for i in range(3))
def walk(ll,arms,t,strength=1):
 for i,o in enumerate(ll):key(o,rot=(math.sin(t*8.5+i*math.pi)*.34*strength,0,0),fr=fr)
 for i,o in enumerate(arms):key(o,rot=(-math.sin(t*8.5+i*math.pi)*.30*strength,(-1 if i==0 else 1)*.07,0),fr=fr)
def camera(pos,target,lens=48):
 key(cam,loc=pos,rot=(Vector(target)-Vector(pos)).to_track_quat('-Z','Y').to_euler(),fr=fr)
 cam.data.lens=lens;cam.data.keyframe_insert('lens',frame=fr)
def look_at(pos,target):return (Vector(target)-Vector(pos)).to_track_quat('-Z','Y').to_euler()
print('FULL PROPS READY',len(bpy.data.objects),flush=True)
for fr in range(1,END+1):
 t=(fr-1)/FPS
 # Default blocking for the street and principal characters.
 hp=(0,0,.03);hr=(0,0,0);hhead=(0,0,2.88);hrot=(0,0,0);hs=1
 lp=(.1,.1,.72);lr=(0,0,0);ls=.001;bs=.001;bp=(0,0,2.88)
 noobpos=(-2.3,4,0);noobscale=.87;arms_up=0
 adminvis=1 if 44.42<=t<53.26 else .001
 for i,(rt,ll,ar,hh,tt) in enumerate(extras):
  pos=[(-2.3,4),(2.4,6.6),(-2.6,10.5),(2.1,13),(-2.2,18),(2.6,22)][i]
  exhead=(0,0,2.88);exrot=(0,0,0);exscale=1;bodyrot=(0,0,0)
  if 12.13<=t<16.48:bodyrot=(.18*math.sin((t-12.13)*6+i),.24*math.sin((t-12.13)*4+i),0)
  if 13.90<=t<44.42:
   u=t-13.9;exhead=(math.sin(u*1.7+i)*.8,math.cos(u*1.4+i)*.7,.64+abs(math.sin(u*4+i))*.18);exrot=(u*2,0,u*.9)
  if t>=44.42:exhead=(0,0,2.88);exrot=(0,0,.13*math.sin(t*3+i))
  if i==0 and 25.64<=t<37.08:
   pos=(1.35,1.2);noobscale=1
   if t>=29.22:exscale=.001
  if t>=53.26:exscale=.001
  key(rt,loc=(pos[0],pos[1],.03),rot=bodyrot,scale=(noobscale if i==0 else .87) if t<53.26 else .001,fr=fr)
  key(hh,loc=exhead,rot=exrot,scale=exscale,fr=fr);walk(ll,ar,t+i,.4)
 if t<5.0:
  py=2.3-t*.8;phase=t*8.5;hp=(math.sin(t*2)*.06,py,.025+abs(math.sin(phase))*.07);hr=(0,0,.05*math.sin(t*2))
  lift=0 if t<3.06 else (1-math.exp(-(t-3.06)*8)+.16*math.sin((t-3.06)*11)*math.exp(-(t-3.06)*2))
  hhead=(0,0,2.88+lift);hrot=(0,.04*math.sin(t*3),.05*math.sin(t*4) if t<3.06 else .22*math.sin((t-3.06)*6))
  for i,o in enumerate(legs):key(o,rot=(math.sin(phase+i*math.pi)*(.34 if t<3.06 else .13),0,0),fr=fr)
  for i,o in enumerate(arms):key(o,rot=(-math.sin(phase+i*math.pi)*.30,(-1 if i==0 else 1)*(.07 if t<3.06 else .40+.1*math.sin(t*8)),0),fr=fr)
  for i,(rt,ll,ar,hh,tt) in enumerate(extras):key(hh,loc=(0,0,2.88+lift*(.7+i*.07)),rot=(0,.12*math.sin(t*6+i) if t>3.06 else 0,0),fr=fr)
  ang=.46-.70*(t/5);dist=8.8-.6*(t/5)-(.25*min(1,(t-3.06)*3) if t>3.06 else 0)
  cp=Vector((math.sin(ang)*dist,py-math.cos(ang)*dist,3.7+.22*math.sin(t*.7)));target=Vector((0,py,2.05+lift*.45));u=max(0,min(1,(t-3.06)*3));cp=target+(cp-target)*(1+.14*u*u*(3-2*u));camera(cp,target)
 elif t<16.48:
  u=t-5;hp=(0,1.3-min(u,3)*.35,.03+abs(math.sin(t*8))*.055);walk(legs,arms,t,.7)
  if t<7.65:camera((2.7,-6.6,3.7),(0,.4,2.05))
  elif t<10.18:
   shake=.10*math.sin(t*42);hp=(shake,.3,.03+abs(math.sin(t*18))*.08);hr=(0,.12*math.sin(t*17),.08*math.sin(t*11));camera((-2.8+shake,-7.2,3.7+shake),(0,1,2))
  elif t<12.13:
   arms_up=.6;camera((1.5,-4.8,3.3),(0,.3,2.55),55)
  elif t<13.90:
   hr=(.18*math.sin((t-12.13)*6),.25*math.sin((t-12.13)*4),0);arms_up=.8;camera((3.5,-8.2,4.5),(0,3,1.8),44)
  else:
   hs=.001;ls=1;u=t-13.9;lp=(smooth(0,1.1,u/1.4),smooth(.3,1.8,u/2),.75+abs(math.sin(u*8))*.35*math.exp(-u));lr=(u*3,.1,u*1.3);camera((3.2,-3.7,1.6),(1,1.8,.9),43)
 elif t<25.64:
  hs=.001;ls=1;lp=(.1,2,.72);hp=(-.7,0,.03);walk(legs,arms,t,1 if t>=20.92 else .15)
  if t<18.72:arms_up=.55;camera((-2.5,-7,3.6),(-.3,.8,2.2))
  elif t<20.92:camera((1.4,-6,3.8),(-.3,.8,2.05),52)
  else:
   hp=(-.7,smooth(0,1.0,(t-20.92)/4.7),.04+abs(math.sin(t*9))*.10);camera((2.8,hp[1]-6.7,3.15),(0,1.5,1.75),47)
 elif t<37.08:
  hs=.001;ls=1;hp=(-.75,.2,.03);lp=(.1,1,.72);walk(legs,arms,t,.15)
  if t<27.77:
   hr=(.22,0,0);key(arms[1],rot=(-.8,0,-.25),fr=fr);camera((2.7,-5.6,2.7),(.2,.8,1.7),49)
  elif t<29.22:
   u=(t-27.77)/1.45;lp=mix((.1,1,.72),(1.35,1.2,2.88),u);lr=(0,0,.15*math.sin(u*math.pi));camera((-2.5,-7.8,4.0),(.3,.7,2.15),46)
  elif t<30.52:
   lp=(1.35,1.2,2.88);camera((-1.9,-7.4,3.8),(.3,.7,2.2),49);arms_up=.8
  elif t<32.22:
   lp=(1.35,1.2,2.88);bs=1;bp=mix((-.75,.15,.6),(-.75,.2,2.88),(t-30.52)/1.7);key(arms[0],rot=(-.65,0,.15),fr=fr);camera((1.8,-5.3,3.5),(-.3,.6,2.1),51)
  else:
   lp=(1.35,1.2,2.88) if t<36.5 else mix((1.35,1.2,2.88),(.3,2.8,.72),(t-36.5)/.58)
   bs=1;bp=(-.75,.2,2.88);arms_up=.55+.12*math.sin(t*7)
   if t<34.18:camera((-.6,-4.1,3.2),(-.75,.2,2.55),55)
   else:camera((1.8+math.sin(t)*.3,-5.8,3.5),(-.45,.5,2.2),52)
 elif t<44.42:
  hs=.001;ls=1;bs=1;hp=(-.9,.1,.03);bp=(-.9,.1,2.88);lp=(.3,2.8,.77);walk(legs,arms,t,.2)
  if t<39.14:camera((2.5,-6.1,3.4),(0,1.5,2.0),48)
  elif t<40.89:camera((1.9,-1.3,1.7),(.3,2.8,1.04),52)
  elif t<41.76:camera((1.1,-1.2,1.50),(.3,2.8,1.13),57)
  elif t<42.64:
   lp=(.3,2.8,.84+.12*math.sin((t-41.76)*9));camera((1.5,-1.7,1.65),(.3,2.8,1.05),54)
  else:
   u=t-42.64;lp=(.3+.32*math.sin(u*6),2.8+u*2.2,.92+abs(math.sin(u*16))*.08);lr=(0,.08*math.sin(u*8),0)
   hp=(-.9, .1+u*1.8,.04+abs(math.sin(t*13))*.10);bp=(hp[0],hp[1],2.88);walk(legs,arms,t,1.4)
   camera((lp[0]+2.3,lp[1]-5.7,1.8),(lp[0],lp[1],1.3),47)
 else:
  hs=.001;bs=1;hp=(-1.5,1,.03);bp=(-1.5,1,2.88);ls=1;lp=(0,8,2.88);walk(legs,arms,t,.2)
  if t<47.65:camera((5,-9,6.3),(0,7,2.0),44)
  elif t<49.12:camera((3.4,1.3,3.7),(0,8,2.1),50)
  elif t<51.97:camera((2.0,2.2,3.5),(0,8,2.3),52)
  elif t<53.26:camera((1.8,3.0,3.1),(0,7.5,1.9),52)
  elif t<55.22:camera((4.6,-8.5,5.4),(0,5,1.6),43)
  else:
   u=min(t,56.6)-55.22;camera((1.1-u*.3,-5.2,2.8),(0,0,1.55),52)
 if 5<=t and arms_up:
  for i,o in enumerate(arms):key(o,rot=(-.18,(-1 if i==0 else 1)*arms_up,0),fr=fr)
 if t>=53.26:hs=.001;ls=.001;bs=.001
 key(hero,loc=hp,rot=hr,scale=1 if t<53.26 else .001,fr=fr)
 key(headroot,loc=hhead,rot=hrot,scale=hs,fr=fr)
 key(loose,loc=lp,rot=lr,scale=ls,fr=fr)
 key(banana_hat,loc=bp,rot=(0,0,.08*math.sin(t*5)),scale=bs,fr=fr)
 for i,l in enumerate(runlegs):
  grow=smooth(.001,1,(t-41.76)/.5) if 41.76<=t<44.42 else .001
  key(l,rot=(math.sin(t*25+i*math.pi)*.65,0,0),scale=grow,fr=fr)
 for i,o in enumerate(streaks):key(o,loc=(lp[0]+1.3+i*.08,lp[1]-.6-i*.17,lp[2]+.4-i*.10),scale=1 if 42.64<=t<44.42 else .001,fr=fr)
 key(admin,scale=adminvis,fr=fr);key(ah,scale=.001,fr=fr);key(console,scale=1 if 47.65<=t<53.26 else .001,fr=fr)
 key(button,loc=(0,0,1.36-(.10 if t>=52.40 else 0)),scale=(.50,.45,.16),fr=fr)
 for i,o in enumerate(aa):key(o,rot=(-.9 if t>=51.97 and i==1 else 0,(-.15 if i==0 else .15),0),fr=fr)
 for i,o in enumerate(banana_people):
  start=53.26+min(i*.045,.28);scale=smooth(.001,1,(t-start)/.18) if t>=start else .001
  tp=min(t,56.60);p=[(0,0),(-2,2),(2,3),(-2.5,6),(2.3,7),(-1.6,11),(1.5,13),(0,8),(-2,17),(2,20)][i]
  key(o,loc=(p[0],p[1],1.45+abs(math.sin(tp*9+i))*.18),rot=(0,.12*math.sin(tp*7+i),.1*math.sin(tp*5+i)),scale=scale,fr=fr)
 for i,o in enumerate(confetti):
  u=max(0,min(t,56.6)-53.26);x=-3+(i%8)*.8;y=(i//8)*2;z=4.8+math.sin(i)*1.2-u*.9
  key(o,loc=(x+.4*math.sin(u*3+i),y,z),rot=(u*4+i,u*3,u*2),scale=1 if 53.26<=t else .001,fr=fr)
 if fr%300==0:print('KEYFRAMES',fr,'/',END,flush=True)
# Dense linear keys ensure every speech anchor is hit without spline overshoot.
for obj in anim:
 if obj.animation_data and obj.animation_data.action:
  for fc in obj.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
for fc in cam.data.animation_data.action.fcurves:
 for k in fc.keyframe_points:k.interpolation='CONSTANT'
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=4;scene.cycles.use_denoising=True;scene.cycles.max_bounces=3;scene.cycles.diffuse_bounces=1;scene.cycles.glossy_bounces=1;scene.render.use_persistent_data=True
scene.render.threads_mode='FIXED';scene.render.threads=8;scene.render.resolution_x=1080;scene.render.resolution_y=1920;scene.render.resolution_percentage=100;scene.render.fps=30;scene.frame_start=1;scene.frame_end=END;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.compression=15
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.05
for sec,name in [(0,'01_HEAD_POP'),(5,'02_EARTHQUAKE'),(16.48,'03_COUNTDOWN'),(25.64,'04_MIXUP'),(37.08,'05_RUNAWAY'),(44.42,'06_BANANA_MODE')]:scene.timeline_markers.new(name,frame=round(sec*30)+1)
scene.frame_set(1);scene.render.filepath=str(R/'frames/frame_')
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Roblox_WhatIf_V2_Full.blend'))
print('FULL_SCENE_SAVED',END,flush=True)
