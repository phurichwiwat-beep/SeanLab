"""Package the editable project after the final export has passed review."""
from pathlib import Path
import json,zipfile
R=Path(__file__).resolve().parent
q=json.loads((R/'output/quality_report.json').read_text())
assert q['status']=='passed' and q.get('visual_review_complete') is True
names=['Roblox_WhatIf_V3.blend','Roblox_WhatIf_V2_Full.blend','base_scene.py','build_full.py','upgrade_v3.py','render_v3.py','prepare_v3.py','assemble_v3.py','validate_v3.py','check_assets_v3.py','pack_v3.py','requirements-render.txt','README_V3.md','README_TH.md','voiceover.wav','mixed_v3.wav','effects_v3.wav','captions.json','shot_cuts.json','v3.ass','Thai.ttf','fonts/Thai.ttf','OFL.txt','audio_subtitle_report.json','asset_integrity_report.json','intro_clean.mp4','output/Roblox_WhatIf_V3_Final.srt','output/quality_report.json']
target=R/'output/Roblox_WhatIf_V3_Source.zip'
names+=['shot_frame_audit.json']+[f'output/contact_sheet_{i}.jpg' for i in range(1,5)]
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in names:z.write(R/name,'V3/'+name)
 z.write(R.parent/'setup_environment.sh','setup_environment.sh')
with zipfile.ZipFile(target) as z:assert z.testzip() is None
print(target,target.stat().st_size)
