# Roblox What If — V3

V3 upgrades the supplied V2 Blender scene, preserving the avatar meshes, city,
six-scene narrative, and original 57.090958-second Thai voiceover. The V2 inputs
remain available alongside the new project. No full V2 final MP4 was supplied;
the editable full scene and clean opening were the visual references.

## Deliverables

- `output/Roblox_WhatIf_V3_Final.mp4`: final vertical H.264/AAC video.
- `Roblox_WhatIf_V3.blend`: editable V3 animation, 1080 × 1920, 30 FPS timeline.
- `output/Roblox_WhatIf_V3_Final.srt`: plain Thai subtitle sidecar.
- `v3.ass`: styled subtitles and timed HUD elements.
- `audio_subtitle_report.json`: narration hash, timing, levels, and effect cues.
- `asset_integrity_report.json`: comparison of original meshes, materials, and caption text.
- `output/quality_report.json`: automated export validation results.

## What changed

- Immediate multi-character head pops and falling bodies; a toy head flies at the
  camera before a surprised close-up. The original narration is not moved.
- Action-led camera cuts, moving perspectives, clearer stolen-head and banana-head
  reveals, a short visual hold at the banana reveal, and tiny-sneaker close-ups.
- An animated Admin button press, brief pause, geometric expanding shockwave, and
  avatar-to-banana replacements at matching positions as the wave reaches them.
- A confused final banana reaction. The old black end card is removed.
- Shorter Thai subtitle clauses, bold white text, yellow keywords, black outline,
  shadow, and mobile-safe margins. Timings use the supplied caption anchors.
- Original synthesized pops, boings, whooshes, scratch, footsteps, countdown,
  impact, and transformation effects. Only effects duck under the narration.

## Reproduce

Run from `/workspace/SeanLab/V3`. The isolated environment is one directory up:

```sh
../.venv-blender/bin/python prepare_v3.py
OMP_NUM_THREADS=5 OPENBLAS_NUM_THREADS=1 ../.venv-blender/bin/python render_v3.py
../.venv-blender/bin/python assemble_v3.py
../.venv-blender/bin/python validate_v3.py
```

The supplied system Blender 4.3.2 lacks OpenImageDenoise. The tested renderer is
the official `bpy==4.3.0` Python package, using Python 3.11, `numpy==1.26.4`, and
`Pillow==12.3.0`. FFmpeg 7.1.5 supplies libx264, AAC, libass, and minterpolate.

Like the supplied V2 production pipeline, the CPU render produces 720 × 1280
source images with 2 Cycles samples and denoising. The first 3.067 seconds use
native 30 FPS frames to keep the fast opening free of interpolation ghosting.
The remainder uses 15 FPS sources, interpolated independently inside each shot.
The brief earthquake shots preserve and repeat their source frames rather than
using optical flow, keeping the fast shake free of doubled facial features.
The image is upscaled to 1080 × 1920 before applying text. This is a 30 FPS export,
not a native 1080p render of every timeline frame. Fast movement in interpolated
sections can show artifacts. The editable Blender project
retains the full 30 FPS animation for higher-quality native rendering if desired.

`render_v3.py` resumes existing images. After changing animation or cameras, move
the affected old images out of `frames_v3/` before rendering them again, or pass
`--frames 17,19,21 --force` for specific timeline frames. `samples_v3/` contains
hard links; assembly refreshes replaced links and invalidates shots when their
source images are newer. There are 903 source PNGs: every frame from 1 through 92,
then odd-numbered frames from 93 through 1713.

To regenerate the V3 animation from V2, run `upgrade_v3.py` using the isolated
Python. This replaces `Roblox_WhatIf_V3.blend`; preserve any manual edits first.
The upgrade does not modify `Roblox_WhatIf_V2_Full.blend` or `voiceover.wav`.

For a quick framing check, run `render_v3.py --preview`; the previews are for
inspection only. Full video rendering is CPU-intensive and takes considerably
longer than the 57-second playback duration.

## Rights and source

Existing character and scene assets are reused from the user-provided V2 files.
New sound effects are synthesized by `prepare_v3.py`; no third-party sound clips
or music were added. `Thai.ttf` is the provided Noto Sans Thai font; see `OFL.txt`.
