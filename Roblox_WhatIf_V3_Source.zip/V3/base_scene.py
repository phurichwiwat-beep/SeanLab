import bpy,math,random,os,sys
from mathutils import Vector
from pathlib import Path
R=Path(__file__).resolve().parent
random.seed(18)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for d in bpy.data.materials:bpy.data.materials.remove(d)
def mat(n,c,metal=0,rough=.46,emission=0):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 if emission:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emission
 return m
navy=mat('Midnight blue',(0.022,.038,.085));white=mat('Warm ivory',(.93,.94,.88));skin=mat('Golden toy plastic',(1,.65,.15),rough=.3);blue=mat('Sky blue jacket',(.025,.47,.92),rough=.3);red=mat('Cherry red',(.8,.018,.055),rough=.32);orange=mat('Orange antler tips',(1,.23,.025));black=mat('Obsidian glasses',(.008,.011,.021),.32,.2);purple=mat('Purple flame',(.46,.025,.94),rough=.25,emission=1.2);lilac=mat('Flame cores',(.8,.27,1),emission=1.7);yellow=mat('Sunflower',(1,.67,.045));asphalt=mat('Blue asphalt',(.13,.20,.27),rough=.9);sidewalk=mat('Cream sidewalk',(.67,.73,.73),rough=.9);glass=mat('Stylized aqua glass',(.08,.50,.61),.23,.18);wood=mat('Warm wood',(.38,.15,.065));leaf=mat('Mint foliage',(.05,.51,.27));leaf2=mat('Lime foliage',(.30,.70,.22));pink=mat('Coral stucco',(.94,.26,.26));teal=mat('Turquoise stucco',(.035,.64,.64));cream=mat('Vanilla stucco',(1,.73,.37));lavender=mat('Lavender stucco',(.43,.34,.77));pavement=mat('Paver edge',(.41,.53,.58));lightmat=mat('Warm light',(1,.8,.35),emission=3)
def empty(n,loc=(0,0,0),parent=None):
 o=bpy.data.objects.new(n,None);bpy.context.collection.objects.link(o);o.location=loc;o.parent=parent;return o
def cube(n,loc,scale,ma,bev=.055,parent=None):
 x,y,z=[v/2 for v in scale]
 verts=[(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
 mesh=bpy.data.meshes.new(n);mesh.from_pydata(verts,[],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);mesh.update()
 o=bpy.data.objects.new(n,mesh);bpy.context.collection.objects.link(o);o.location=loc;o.data.materials.append(ma)
 if bev:
  mod=o.modifiers.new('Soft toy edges','BEVEL');mod.width=bev;mod.segments=2
  mod=o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
 o.parent=parent;return o
def cone(n,loc,rad,depth,ma,vertices=6,parent=None):
 bpy.ops.mesh.primitive_cone_add(vertices=vertices,radius1=rad,radius2=0,depth=depth,location=loc);o=bpy.context.object;o.name=n;o.data.materials.append(ma);o.parent=parent;return o
def ico(n,loc,scale,ma,sub=1):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=1,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(ma);return o
def rod(n,a,b,r,ma,parent=None):
 mid=(Vector(a)+Vector(b))/2;v=Vector(b)-Vector(a)
 bpy.ops.mesh.primitive_cylinder_add(vertices=8,radius=r,depth=v.length,location=mid);o=bpy.context.object;o.name=n;o.rotation_euler=v.to_track_quat('Z','Y').to_euler();o.data.materials.append(ma);o.parent=parent;return o
def txt(n,body,loc,size,ma,rot=(math.pi/2,0,0)):
 curve=bpy.data.curves.new(n,'FONT');curve.body=body;curve.align_x='CENTER';curve.align_y='CENTER';curve.size=size;curve.extrude=.008;curve.bevel_depth=.002;o=bpy.data.objects.new(n,curve);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=rot;o.data.materials.append(ma);return o
# A full street, rather than a camera-facing set of rectangles.
cube('Ground',(0,6,-.28),(120,120,.4),teal,.0)
cube('Road',(0,5,-.035),(8.2,90,.18),asphalt,.02)
for side in [-1,1]:
 cube('Raised sidewalk',(side*6.2,5,.04),(4.1,90,.35),sidewalk,.05)
 for y in range(-30,39,2):
  cube('Curb block',(side*4.22,y,.19),(.30,1.85,.42),white,.035)
  for x in [4.7,5.7,6.7,7.7]:cube('Sidewalk grout',(side*x,y,.223),(.018,1.98,.008),pavement,0)
for y in range(-35,44,4):
 for x in [-.12,.12]:cube('Lane marking',(x,y,.065),(.085,1.8,.012),yellow,.005)
for y in [-5,12,26]:
 for x in [-2.8,-1.6,-.4,.8,2.0]:cube('Crosswalk',(x,y,.07),(.66,2,.015),white,.015)
# Detailed storefronts and upper floors.
for side in [-1,1]:
 for j,y in enumerate(range(-14,35,7)):
  h=[6.5,8.2,7.4,9.5][j%4];ma=[pink,teal,cream,lavender][(j+(1 if side>0 else 0))%4];x=side*9
  cube('Building shell',(x,y,h/2+.22),(5.4,6.5,h),ma,.12)
  cube('Roof cornice',(x,y,h+.23),(5.65,6.72,.24),white,.055)
  cube('Roof inset',(x,y,h+.42),(5.15,6.16,.15),navy,.02)
  face=side*6.24
  for zz in [3.6,5.3,7.0]:
   if zz>h-.5:continue
   for yy in [y-2.1,y,y+2.1]:
    cube('Window frame',(face,yy,zz),(.15,1.42,1.2),white,.035)
    cube('Reflective window',(face-side*.095,yy,zz+.02),(.04,1.20,.99),glass,.01)
    cube('Window mullion',(face-side*.13,yy,zz),(.06,.07,1.05),white,.01)
    cube('Window sill',(face-side*.18,yy,zz-.66),(.43,1.60,.15),white,.025)
  cube('Store glass',(face-side*.02,y,1.45),(.11,5.5,2.2),glass,.025)
  for yy in [y-2.7,y-.8,y+.8,y+2.7]:cube('Shop pillar',(face-side*.1,yy,1.5),(.27,.17,2.45),white,.02)
  for k in range(9):
   aw=cube('Striped awning',(face-side*.56,y-2.67+k*.66,2.75),(1.23,.65,.18),white if k%2 else red,.025);aw.rotation_euler[1]=side*.12
  cube('Shop sign',(face-side*.17,y,3.03),(.18,4.9,.55),navy,.045)
  sign=txt('Store name',['BLOCK MART','BLOX CAFE','NOOB GEAR','TOY DISTRICT'][j%4],(face-side*.29,y,3.05),.31,white)
  sign.rotation_euler=(math.pi/2,0,-side*math.pi/2)
  for yy in [y-2.85,y+2.85]:cube('Store corner trim',(face,yy,1.57),(.35,.24,2.8),cream,.035)
# City props: trees, street lights, benches, bollards and road signs.
for side in [-1,1]:
 for j,y in enumerate(range(-13,32,7)):
  x=side*5.1
  cube('Planter',(x,y,.43),(1.2,1.2,.65),navy,.08)
  rod('Tree trunk',(x,y,.7),(x,y,3.4),.14,wood)
  ico('Canopy',(x,y,3.65),(1.02,.95,1.22),leaf,2);ico('Canopy highlight',(x-.3,y-.2,4.2),(.8,.72,.85),leaf2,1)
  lx=side*4.65;ly=y+3.1
  rod('Lamp post',(lx,ly,.25),(lx,ly,4.8),.065,navy)
  rod('Lamp arm',(lx,ly,4.8),(lx-side*.7,ly,4.8),.06,navy)
  cube('Street lamp shade',(lx-side*.7,ly,4.77),(.65,.5,.15),navy,.04)
  cube('Glowing lamp',(lx-side*.7,ly,4.68),(.46,.36,.05),lightmat,.02)
  if j%2==0:
   cube('Bench seat',(side*6.1,y+2,.76),(1.65,.65,.18),wood,.045)
   cube('Bench back',(side*6.1,y+2.28,1.15),(1.65,.13,.65),wood,.04)
   for dx in [-.6,.6]:cube('Bench leg',(side*6.1+dx,y+2,.43),(.12,.45,.6),navy,.02)
for y in [-1,6,13]:
 for side in [-1,1]:
  rod('Bollard',(side*4.5,y,.23),(side*4.5,y,1.1),.10,navy)
  cube('Bollard reflector',(side*4.5,y,.9),(.23,.23,.1),yellow,.02)
print('CITY COMPLETE',len(bpy.data.objects),flush=True)
# Hero model with separate limbs and head rig.
hero=empty('HERO_ROOT');parts=[]
def avatar(root,name,is_hero=True):
 torso=empty(name+'_torso',(0,0,1.83),root)
 cube('Jacket',(0,0,0),(1.12,.61,1.02),blue if is_hero else teal,.09,torso)
 if is_hero:
  cube('White front panel',(0,-.322,.02),(.8,.04,.81),white,.025,torso)
  cube('Jacket zip',(0,-.355,.02),(.035,.025,.84),navy,.005,torso)
  cube('Flag patch border',(-.20,-.36,.19),(.38,.03,.24),navy,.01,torso)
  for k,col in enumerate([red,white,navy,white,red]):cube('Thai flag stripe',(-.2,-.382,.275-k*.043),(.33,.015,.043),col,.001,torso)
  for x in [-.42,.42]:cube('Jacket hem',(x,-.35,-.37),(.18,.025,.10),blue,.008,torso)
 legs=[];arms=[]
 for q in [-1,1]:
  leg=empty(name+'_leg',(q*.29,0,1.32),root);legs.append(leg)
  cube('Trouser leg',(0,0,-.49),(.46,.5,.9),navy,.055,leg)
  cube('Red sneaker',(0,-.15,-1.03),(.51,.82,.29),red if is_hero else blue,.08,leg)
  cube('Sneaker sole',(0,-.15,-1.16),(.52,.83,.075),white,.025,leg)
  for yy in [-.38,-.26]:cube('Shoe lace',(0,yy,-.893),(.29,.04,.022),white,.005,leg)
  arm=empty(name+'_arm',(q*.75,0,2.22),root);arms.append(arm)
  cube('Sleeve',(0,0,-.29),(.35,.50,.61),blue if is_hero else teal,.065,arm)
  cube('Hand',(0,0,-.76),(.36,.47,.37),skin,.07,arm)
  cube('Cuff',(0,0,-.57),(.37,.51,.13),white,.025,arm)
  if is_hero:
   for k in range(3):
    f=cone('Shoulder purple flame',(q*.1+(k-1)*.14,0,.12+k*.09),.16,.53+k*.12,purple,5,arm);f.rotation_euler[1]=q*.23
    cone('Flame bright core',(q*.1+(k-1)*.14,-.09,.08+k*.09),.075,.37,lilac,5,arm)
 headroot=empty(name+'_head',(0,0,2.88),root)
 cube('Block head',(0,0,0),(.94,.85,.86),skin,.105,headroot)
 cube('Neck',(0,0,-.49),(.31,.31,.19),skin,.04,headroot)
 if is_hero:
  cube('Hair base',(0,.0,.39),(1.01,.87,.23),red,.055,headroot)
  for i in range(7):
   x=-.44+i*.145;h=[.32,.52,.43,.66,.5,.44,.34][i]
   spike=cone('Red angular hair spike',(x,-.04,.49+h/2),.205,h,red,4,headroot);spike.rotation_euler[1]=(i-3)*.13
  for q in [-1,1]:
   # Actual branching antlers, with orange ends.
   a=(q*.36,.10,.48);b=(q*.62,.12,.98);c=(q*.79,.1,1.38)
   rod('Black antler',a,b,.072,black,headroot);rod('Black antler',b,c,.055,black,headroot)
   rod('Orange antler tip',(q*.74,.1,1.26),c,.058,orange,headroot)
   rod('Antler branch',(q*.59,.12,.91),(q*.94,.12,1.06),.05,black,headroot)
   rod('Orange branch tip',(q*.83,.12,1.01),(q*.97,.12,1.08),.052,orange,headroot)
  for q in [-1,1]:
   cube('Pixel sunglasses',(q*.236,-.442,.08),(.42,.095,.25),black,.015,headroot)
   cube('Lens glint',(q*.236-.08,-.495,.13),(.09,.012,.025),white,.002,headroot)
  cube('Glasses bridge',(0,-.455,.11),(.10,.09,.06),black,.005,headroot)
 else:
  for q in [-1,1]:cube('Eye',(q*.19,-.432,.08),(.09,.025,.12),black,.015,headroot)
 # Friendly curved toy smile.
 cu=bpy.data.curves.new('Smile','CURVE');cu.dimensions='3D';cu.bevel_depth=.018;cu.bevel_resolution=2
 sp=cu.splines.new('POLY');sp.points.add(16)
 for i,p in enumerate(sp.points):
  a=math.pi+math.pi*i/16;p.co=(.20*math.cos(a),-.445,-.12+.105*math.sin(a),1)
 o=bpy.data.objects.new('Smile',cu);bpy.context.collection.objects.link(o);o.parent=headroot;o.data.materials.append(black)
 return legs,arms,headroot,torso
legs,arms,headroot,torso=avatar(hero,'Hero')
extras=[]
for i,(x,y) in enumerate([(-2.3,4.0),(2.4,6.6),(-2.6,10.5),(2.1,13),(-2.2,18),(2.6,22)]):
 rt=empty('CITY_NOOB_'+str(i),(x,y,0));ll,aa,hh,tt=avatar(rt,'Noob'+str(i),False);rt.scale=(.87,.87,.87);extras.append((rt,ll,aa,hh,tt))
print('CHARACTERS COMPLETE',flush=True)
# Soft studio-style sun, skylight and warm rim light.
world=bpy.data.worlds.new('Pastel blue sky');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.42,.66,.83,1);world.node_tree.nodes['Background'].inputs[1].default_value=.65;bpy.context.scene.world=world
def light(n,typ,loc,energy,color,size=5):
 bpy.ops.object.light_add(type=typ,location=loc);o=bpy.context.object;o.name=n;o.data.energy=energy;o.data.color=color
 if typ=='AREA':o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,2,1.5))-o.location).to_track_quat('-Z','Y').to_euler()
 return o
sun=light('Golden afternoon sunlight','SUN',(0,0,10),2.2,(1,.80,.64));sun.rotation_euler=(math.radians(28),math.radians(-24),math.radians(-35));sun.data.angle=.15
light('Large soft key','AREA',(-3,-5,9),850,(1,.87,.72),7)
light('Cool fill','AREA',(4,-1,6),450,(.60,.79,1),6)
light('Purple rim','AREA',(0,7,6),650,(.73,.53,1),5)
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='Cinematic tracking camera';cam.data.lens=48;cam.data.sensor_width=36;cam.data.clip_end=250
scene=bpy.context.scene;scene.camera=cam
# Frame-specific rig animation: walk, reaction, then toy head pop at spoken cue.
for fr in range(1,151):
 t=(fr-1)/30;py=2.3-t*.8;phase=t*8.5
 hero.location=(math.sin(t*2)*.06,py,.025+abs(math.sin(phase))*.07);hero.rotation_euler[2]=.05*math.sin(t*2)
 hero.keyframe_insert('location',frame=fr);hero.keyframe_insert('rotation_euler',frame=fr)
 for i,leg in enumerate(legs):leg.rotation_euler[0]=math.sin(phase+i*math.pi)*.34 if t<3.06 else math.sin(phase+i*math.pi)*.13;leg.keyframe_insert('rotation_euler',frame=fr)
 for i,arm in enumerate(arms):
  arm.rotation_euler[0]=-math.sin(phase+i*math.pi)*.30;arm.rotation_euler[1]=(-1 if i==0 else 1)*(.07 if t<3.06 else .40+.1*math.sin(t*8));arm.keyframe_insert('rotation_euler',frame=fr)
 lift=0 if t<3.06 else (1.0*(1-math.exp(-(t-3.06)*8))+.16*math.sin((t-3.06)*11)*math.exp(-(t-3.06)*2))
 headroot.location.z=2.88+lift;headroot.rotation_euler=(0,.04*math.sin(t*3),.05*math.sin(t*4) if t<3.06 else .22*math.sin((t-3.06)*6));headroot.keyframe_insert('location',frame=fr);headroot.keyframe_insert('rotation_euler',frame=fr)
 for j,(rt,ll,aa,hh,tt) in enumerate(extras):
  hh.location.z=2.88+(lift*(.7+j*.07));hh.rotation_euler[1]=.12*math.sin(t*6+j) if t>3.06 else 0;hh.keyframe_insert('location',frame=fr);hh.keyframe_insert('rotation_euler',frame=fr)
  for k,l in enumerate(ll):l.rotation_euler[0]=.23*math.sin(phase+j+k*math.pi);l.keyframe_insert('rotation_euler',frame=fr)
 # Smooth left-to-right orbit and dolly; reaction pullback for the floating head at 3.06s.
 ang=.46-.70*(t/5);dist=8.8-.6*(t/5)-(.25*min(1,(t-3.06)*3) if t>3.06 else 0)
 cam.location=(math.sin(ang)*dist,py-math.cos(ang)*dist,3.7+.22*math.sin(t*.7))
 target=Vector((0,py,2.05+lift*.45));u=max(0,min(1,(t-3.06)*3));ease=u*u*(3-2*u);cam.location=target+(cam.location-target)*(1+.14*ease);cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.keyframe_insert('location',frame=fr);cam.keyframe_insert('rotation_euler',frame=fr)
for obj in bpy.data.objects:
 if obj.animation_data and obj.animation_data.action:
  for fc in obj.animation_data.action.fcurves:
   for kp in fc.keyframe_points:kp.interpolation='LINEAR'
print('ANIMATION COMPLETE',flush=True)
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8;scene.cycles.use_denoising=True;scene.cycles.max_bounces=4;scene.cycles.diffuse_bounces=2;scene.cycles.glossy_bounces=2
scene.render.threads_mode='FIXED';scene.render.threads=8
scene.render.resolution_x=1080;scene.render.resolution_y=1920;scene.render.resolution_percentage=100;scene.render.fps=30;scene.frame_start=1;scene.frame_end=150
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.compression=15
scene.render.film_transparent=False;scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.05
scene.render.filepath=str(R/'frames/frame_');scene.render.use_file_extension=True
scene.frame_set(40)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Roblox_WhatIf_V2.blend'))
if '--test' in sys.argv:
 scene.render.resolution_percentage=50;scene.render.filepath=str(R/'output/lookdev.png');bpy.ops.render.render(write_still=True)
