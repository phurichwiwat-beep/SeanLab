"""Interpolate inside each shot only, then burn captions and mix the original voice."""
from pathlib import Path
import json,math,os,subprocess,time,concurrent.futures,sys
R=Path(__file__).resolve().parent
smoke='--smoke' in sys.argv or '--smoke-interpolation' in sys.argv
stage=R/'samples_v3';stage.mkdir(exist_ok=True)
for i,fr in enumerate(range(1,46 if '--smoke' in sys.argv else 1714,2),1):
 src=R/'frames_v3'/f'frame_{fr:04d}.png';dst=stage/f'sample_{i:04d}.png'
 if not src.exists():raise FileNotFoundError(src)
 if dst.exists() and not os.path.samefile(src,dst):dst.unlink()
 if not dst.exists():os.link(src,dst)
cuts=sorted(set([round(t*30) for t in json.loads((R/'shot_cuts.json').read_text())]+[1713]))
chunks=R/'chunks_v3';chunks.mkdir(exist_ok=True)
def encode(job):
 j,start,end=job;target=chunks/f'shot_{j:02d}.mp4'
 first=math.ceil(start/2);last=math.floor((end-1)/2);n=last-first+1
 native=end<=92
 sources=[R/'frames_v3'/f'frame_{k:04d}.png' for k in range(start+1,end+1)] if native else [stage/f'sample_{k+1:04d}.png' for k in range(first,last+1)]
 if target.exists():
  try:
   meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=nb_frames','-of','json',str(target)]))
   newest=max(p.stat().st_mtime for p in sources)
   if int(meta['streams'][0]['nb_frames'])==end-start and target.stat().st_mtime>=newest:return target
  except (ValueError,KeyError,IndexError,subprocess.SubprocessError):pass
 # setpts clears the link rate in FFmpeg 7.1; tpad needs it restored explicitly.
 # Preserve individual poses during the fast earthquake shake; optical flow
 # produces doubled facial features when the motion reverses this quickly.
 resample='fps=30' if 230<=start and end<=308 else 'minterpolate=fps=30:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1:scd=fdiff:scd_threshold=5'
 vf=f'trim=end_frame={n},setpts=PTS-STARTPTS,fps=15,tpad=stop_mode=clone:stop_duration=0.4,{resample}'
 cmd=['ffmpeg','-y','-v','error','-threads','1','-filter_threads','1','-framerate','15','-start_number',str(first+1),'-t',str(n/15),'-i',str(stage/'sample_%04d.png'),'-vf',vf,'-frames:v',str(end-start),'-r','30','-c:v','libx264','-threads','1','-crf','16','-preset','fast','-pix_fmt','yuv420p','-an',str(target)]
 if native:
  cmd=['ffmpeg','-y','-v','error','-threads','1','-framerate','30','-start_number',str(start+1),'-i',str(R/'frames_v3/frame_%04d.png'),'-frames:v',str(end-start),'-r','30','-c:v','libx264','-threads','1','-crf','16','-preset','fast','-pix_fmt','yuv420p','-an',str(target)]
 with (chunks/f'shot_{j:02d}.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
 meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=nb_frames','-of','json',str(target)]))
 actual=int(meta['streams'][0]['nb_frames'])
 if actual!=end-start:raise RuntimeError(f'Shot {j}: expected {end-start} frames, got {actual}')
 print('SHOT_READY',j,start,end,flush=True);return target
jobs=[(j,a,b) for j,(a,b) in enumerate(zip(cuts,cuts[1:]))]
if '--smoke' in sys.argv:jobs=jobs[:2]
elif '--smoke-interpolation' in sys.argv:jobs=[jobs[k] for k in [4,5,10,42]]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:outputs=list(pool.map(encode,jobs))
if smoke:
 print('ASSEMBLY_SMOKE_PASSED',flush=True);sys.exit(0)
playlist=R/'concat_v3.txt';playlist.write_text(''.join(f"file 'chunks_v3/{p.name}'\n" for p in outputs))
vf='scale=1080:1920:flags=lanczos,ass=v3.ass:fontsdir=fonts'
cmd=['ffmpeg','-y','-hide_banner','-threads','2','-filter_threads','2','-f','concat','-safe','0','-i',str(playlist),'-i',str(R/'mixed_v3.wav'),'-vf',vf,'-map','0:v','-map','1:a','-r','30','-c:v','libx264','-threads','3','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-t','57.090958','-movflags','+faststart',str(R/'output/Roblox_WhatIf_V3_Final.mp4')]
with (R/'encode_v3.log').open('w') as log:subprocess.run(cmd,cwd=R,stdout=log,stderr=log,check=True)
print('V3_MP4_READY',flush=True)
