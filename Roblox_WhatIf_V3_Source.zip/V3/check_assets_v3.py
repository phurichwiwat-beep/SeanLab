"""Verify that V3 retains the supplied meshes, materials, and caption text."""
from pathlib import Path
from array import array
import bpy,hashlib,json,re
R=Path(__file__).resolve().parent
def snapshot(path):
 bpy.ops.wm.open_mainfile(filepath=str(path));meshes={};materials={}
 for o in bpy.data.objects:
  if o.type!='MESH':continue
  m=o.data;h=hashlib.sha256()
  for owner,attr,typ,n in [(m.vertices,'co','f',len(m.vertices)*3),(m.loops,'vertex_index','i',len(m.loops)),(m.polygons,'loop_total','i',len(m.polygons)),(m.polygons,'material_index','i',len(m.polygons))]:
   a=array(typ,[0])*n;owner.foreach_get(attr,a);h.update(a.tobytes())
  h.update(json.dumps([x.name if x else None for x in m.materials]).encode())
  meshes[o.name]=h.hexdigest()
 for m in bpy.data.materials:
  p=m.node_tree.nodes.get('Principled BSDF') if m.use_nodes else None
  materials[m.name]={'diffuse':list(m.diffuse_color),'base':list(p.inputs['Base Color'].default_value) if p else None,'roughness':float(p.inputs['Roughness'].default_value) if p else None}
 return meshes,materials
original,original_mats=snapshot(R/'Roblox_WhatIf_V2_Full.blend')
upgraded,upgraded_mats=snapshot(R/'Roblox_WhatIf_V3.blend')
assert all(upgraded.get(n)==h for n,h in original.items()),'An original mesh changed'
assert all(upgraded_mats.get(n)==m for n,m in original_mats.items()),'An original material changed'
caps=json.loads((R/'captions.json').read_text())
expected=''.join(c+d for _,_,c,d in caps)
srt=(R/'output/Roblox_WhatIf_V3_Final.srt').read_text()
actual=''.join(block.splitlines()[2] for block in srt.strip().split('\n\n'))
assert actual==expected,'The original caption text changed'
report={'status':'passed','original_mesh_objects_preserved':len(original),'original_materials_preserved':len(original_mats),'original_caption_text_preserved':True,'original_blend_sha256':hashlib.sha256((R/'Roblox_WhatIf_V2_Full.blend').read_bytes()).hexdigest(),'v3_blend_sha256':hashlib.sha256((R/'Roblox_WhatIf_V3.blend').read_bytes()).hexdigest(),'note':'Object animation and expressions change deliberately; original mesh coordinates, topology, material assignments, and material colors are preserved.'}
(R/'asset_integrity_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
