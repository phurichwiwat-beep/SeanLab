"""Upgrade the supplied V2 scene without rebuilding or redesigning its assets."""
from pathlib import Path
import bpy, math, json
from mathutils import Vector, Euler

R = Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'Roblox_WhatIf_V2_Full.blend'))
s = bpy.context.scene
FPS=30; END=1713
O=bpy.data.objects
hero=O['HERO_ROOT']; head=O['Hero_head']; prop=O['HERO_HEAD_PROP']; cam=s.camera
extras=[O[f'CITY_NOOB_{i}'] for i in range(6)]
heads=[O[f'Noob{i}_head'] for i in range(6)]
bananas=[O[f'BANANA_CITIZEN_{i}'] for i in range(10)]
arms=[O['Hero_arm'],O['Hero_arm.001']]
legs=[O['Hero_leg'],O['Hero_leg.001']]
runlegs=[O['Tiny running leg'],O['Tiny running leg.001']]
admin=O['ADMIN_ROOT']; console=O['BANANA_CONSOLE']; hat=O['HERO_BANANA_HEAD']
aa=[O['Admin_arm'],O['Admin_arm.001']]
smile=next(o for o in head.children if o.name.startswith('Smile'))
curve=bpy.data.curves.new('V3 surprised mouth curve','CURVE');curve.dimensions='3D';curve.bevel_depth=.018;curve.bevel_resolution=2
sp=curve.splines.new('POLY');sp.points.add(23);sp.use_cyclic_u=True
for i,p in enumerate(sp.points):
 a=2*math.pi*i/24;p.co=(.10*math.cos(a),-.46,-.15+.13*math.sin(a),1)
shock=bpy.data.objects.new('V3 surprised mouth',curve);bpy.context.collection.objects.link(shock);shock.parent=head
curve.materials.append(smile.data.materials[0])
banana_mesh_root=next(o for o in bananas[0].children if o.name.startswith('Whole banana'))
banana_grin=next(o for o in banana_mesh_root.children if o.name.startswith('Banana grin'))

# A real geometric shockwave, rather than a text-only transformation.
mat=bpy.data.materials.new('V3 banana energy');mat.diffuse_color=(1,.62,.015,1)
mat.use_nodes=True;p=mat.node_tree.nodes.get('Principled BSDF')
p.inputs['Base Color'].default_value=(1,.62,.015,1)
p.inputs['Emission Color'].default_value=(1,.35,.005,1);p.inputs['Emission Strength'].default_value=2
bpy.ops.mesh.primitive_torus_add(major_radius=1,minor_radius=.045,major_segments=96,minor_segments=8,location=(0,6.8,.15))
wave=bpy.context.object;wave.name='V3_TRANSFORMATION_WAVE';wave.data.materials.append(mat)

changed=[hero,head,prop,cam,hat,admin,console,O['BIG_RED_BUTTON'],wave,O['Noob0_arm'],smile,shock,banana_grin]+extras+heads+bananas+arms+legs+runlegs+aa
changed=list(dict.fromkeys(changed))
tracks={o.name:{'location':[],'rotation_euler':[],'scale':[]} for o in changed}
lenses=[]
def clamp(x):return max(0,min(1,x))
def ease(x):x=clamp(x);return x*x*(3-2*x)
def mix(a,b,u):return tuple(x+(y-x)*u for x,y in zip(a,b))
def view(pos,target,lens=48):
 cam.location=pos;cam.rotation_euler=(Vector(target)-Vector(pos)).to_track_quat('-Z','Y').to_euler();cam.data.lens=lens
def val(o,loc=None,rot=None,scale=None):
 if loc is not None:o.location=loc
 if rot is not None:o.rotation_euler=rot
 if scale is not None:o.scale=(scale,)*3 if isinstance(scale,(float,int)) else scale
def world_head(rt,hh,pos):
 # Explicit parent transform avoids a fallen torso dragging a popped head underground.
 m=rt.matrix_basis
 hh.location=m.inverted() @ Vector(pos)

cuts=[0,.5,1.5,2.3,3.06,4.15,5,6.38,7.65,9.42,10.27,10.85,12.13,13.9,15.05,16.48,18.72,20.92,23.08,24.4,25.64,27.77,29.22,30.52,32.22,32.7,34.18,35.02,36.5,37.08,39.14,40.89,41.76,42.64,43.5,44.42,45.56,47.65,49.12,50.6,51.97,52.4,52.85,53.26,54.35,55.22,56.25]
citizen_xy=[(-1.5,1),(-2.3,4),(2.4,6.6),(-2.6,10.5),(2.1,13),(-2.2,18),(2.6,22),(0,8),(-1.8,25),(2,28)]
for fr in range(1,END+1):
 s.frame_set(fr);t=(fr-1)/30
 wave.scale=(.001,)*3
 val(shock,scale=1 if 1.5<=t<3.06 else .001)
 val(smile,scale=.001 if 1.5<=t<3.06 else 1)
 val(banana_grin,loc=(0,0,-.15) if t>=55.22 else (0,0,0),scale=(1,1,-1) if t>=55.22 else 1)
 if t<5:
  # Flash-forward: action starts on frame one; the original narrative resumes at 5 s.
  val(hero,(0,0,.03),(0,0,0),1)
  if .5<=t<1.5:val(hero,(-2.4,0,.03))
  lift=.16+1.1*math.sin(min(t/.5,1)*math.pi/2)
  if t>=1.5:lift=.42+.10*math.sin(t*8)
  val(head,(0,0,2.88+lift),(0,.12*math.sin(t*7),.16*math.sin(t*5)),1)
  val(prop,scale=.001)
  for j,o in enumerate(arms):val(o,rot=(-.45,(-1 if j==0 else 1)*(.7+.12*math.sin(t*12)),0))
  for j,o in enumerate(legs):val(o,rot=(.12*math.sin(t*12+j*math.pi),0,0))
  for i,(rt,hh) in enumerate(zip(extras,heads)):
   xy=[(-2.2,2.5),(2.1,3.5),(-2.4,7),(2.3,9),(-2.2,13),(2.3,16)][i]
   fall=ease((t-.08)/.38)
   val(rt,(*xy,.03),(.85*fall,(-1 if i%2 else 1)*.22*fall,0),.87)
   if t<.5:
    z=2.65+1.4*math.sin(clamp((t+.08)/.65)*math.pi/2)
    wp=(xy[0]+.2*math.sin(t*7+i),xy[1]-.3*t,z)
   else:
    u=t-.5;z=.65+abs(math.sin(u*7+i*.3))*1.1*math.exp(-u*.6)
    wp=(xy[0]+.6*math.sin(u*2+i),xy[1]-u*.9,z)
   if i==0 and .5<=t<1.5:
    # One toy head flies directly toward the low camera.
    u=ease((t-.5));wp=mix((-.3,2.5,1.4),(.8,-2.2,1.4),u)
   world_head(rt,hh,wp);val(hh,rot=(t*4,0,t*2),scale=1)
  if t<.5:
   u=ease(t/.5);view(mix((5,-10,6),(3.1,-7,4.7),u),(0,3,2.5),40)
  elif t<1.5:view((1.2,-4.7+(.3*(t-.5)),1.15),(0,3,1.15),33)
  elif t<2.3:view((.6,-5.8+(t-1.5)*.7,4.15),(0,0,3.55),50)
  elif t<3.06:view((-.7,-4.4,3.8),(0,0,3.35),51)
  elif t<4.15:view((3.8,-7.7,4.8),(0,2,2.1),42)
  else:view((.8,-6.0,3.8),(0,0,3.2),46)
 elif t<7.65:
  u=t-5;view((2.8-u*.42,-6.2+u*.18,3.65),(0,.5,2.05),47)
 elif 9.42<=t<10.27:view((-.7,-5.3+(t-9.42)*.6,3.5),(0,.3,2.8),52)
 elif 10.27<=t<10.85:view((.6,-4.8,3.6),(0,.3,2.85),55)
 elif 10.85<=t<12.13:view((-1,-5.8+(t-10.85)*.25,3.5),(0,.3,2.6),50)
 elif 12.13<=t<13.9:
  u=ease((t-12.13)/1.1)
  for i,(rt,hh) in enumerate(zip(extras,heads)):
   val(rt,rot=(.85*u,(-1 if i%2 else 1)*.18*u,0))
  view((3.6,-7.9+(t-12.13)*.4,4.5),(0,3,1.7),42)
 elif 13.9<=t<16.48:
  u=t-13.9
  val(prop,(.1+u*.45,.6+u*.7,.88+abs(math.sin(u*8))*1.1*math.exp(-u*.7)),(.16*math.sin(u*6),.12*math.sin(u*4),u*1.3),1)
  if t<15.05:view((2.7,-4+u*.3,1.6),(prop.location.x,prop.location.y,1.1),44)
  else:view((-.9,-3.8+u*.4,1.3),(prop.location.x,prop.location.y,1.0),43)
 elif 16.48<=t<18.72:view((-2.1,-6.3+(t-16.48)*.2,3.8),(-.3,.8,2.3),48)
 elif 18.72<=t<20.92:view((.8,-5.8+(t-18.72)*.3,3.5),(-.5,.5,2.35),52)
 elif 23.08<=t<25.64:
  if t<24.4:view((-.9,-5.6+(t-23.08)*.35,3.2),(-.6,1,2.15),49)
  else:view((2.6,-5.2,1.25),(.1,2,.8),45)
 elif 25.64<=t<27.77:
  u=ease((t-25.64)/1.8);val(hero,mix((-1.5,-.6,.03),(-.75,.2,.03),u))
  for j,o in enumerate(legs):val(o,rot=(.62*math.sin(t*15+j*math.pi),0,0))
  view((2.6,-5.3+(t-25.64)*.25,2.8),(.2,.8,1.6),47)
 elif 27.77<=t<29.22:
  u=ease((t-27.77)/1.45)
  val(prop,mix((.1,1,.72),(1.35,1.2,2.88),u),(0,0,.13*math.sin(u*math.pi)))
  a=O['Noob0_arm'];val(a,rot=(-1.5*math.sin(u*math.pi),-.5,0))
  view((-2.4,-6.3+(t-27.77)*.3,3.5),(.4,.9,2),46)
 elif 29.22<=t<30.52:
  # The stolen head and its new body fill the right of frame; hero reacts on left.
  u=ease((t-29.22)/.22);view(mix((-1.9,-6.5,3.9),(-1.15,-5.4,3.6),u),(.5,.8,2.5),49)
  for j,o in enumerate(arms):val(o,rot=(-.2,(-1 if j==0 else 1)*1.0,0))
 elif 30.52<=t<32.22:view((1.5,-5.1+(t-30.52)*.25,3.45),(-.55,.2,2.45),49)
 elif 32.22<=t<34.18:
  # Brief locked reveal, followed by the reaction push; narration keeps playing.
  u=0 if t<32.7 else ease((t-32.7)/1.2)
  view(mix((-.55,-4.7,3.0),(-.4,-4.1,3.1),u),(-.75,.2,2.5),51)
  val(hat,rot=(0,0,.12 if t<32.7 else .12*math.sin(t*5)))
 elif 34.18<=t<35.02:view((1.6,-5.5,3.3),(-.4,.6,2.3),49)
 elif 35.02<=t<36.5:view((-.8,-4.5+(t-35.02)*.25,3.15),(-.75,.2,2.5),53)
 elif 39.14<=t<41.76:
  view((1.6,-1.8+(t-39.14)*.12,1.45),(.3,2.8,1.1),49 if t<40.89 else 55)
 elif 41.76<=t<42.64:
  # Frame both sneakers and the head: feet must read as geometry, not a caption.
  val(prop,(.3,2.8,1.13+.035*math.sin(t*18)),(0,0,0))
  view((1.0,-1.7,1.15),(.3,2.8,.95),47)
 elif 42.64<=t<44.42:
  u=t-42.64;pos=(.3+.4*math.sin(u*5),2.8+u*3,1.13+abs(math.sin(u*23))*.06)
  val(prop,pos,(0,.05*math.sin(u*12),-.1*math.sin(u*5)))
  for j,o in enumerate(runlegs):val(o,rot=(.9*math.sin(u*35+j*math.pi),0,0),scale=1)
  if t<43.5:view((pos[0]+2.1,pos[1]-4.7,1.5),(pos[0],pos[1],1),44)
  else:view((pos[0]+1.5,pos[1]-3.8,1.9),(pos[0],pos[1],1.1),44)
 elif 44.42<=t<47.65:
  # Wrong-head tableau stays visible before the Admin reveal.
  u=t-44.42;view((4-u*.25,-7.6+u*.3,5),(0,6,2),42)
 elif 47.65<=t<49.12:view((3,1.4+(t-47.65)*.3,3.9),(0,8,2.8),48)
 elif 49.12<=t<50.6:view((.7,2.6+(t-49.12)*.2,3.8),(0,8,3.1),51)
 elif 50.6<=t<51.97:view((-1.4,2,3.5),(0,8,2.5),49)
 elif 51.97<=t<52.85:
  view((1.65,3.7,2.65),(0,6.9,1.55),45)
  # Reach forward and across to the red button, then depress it at the sound anchor.
  u=ease((t-51.97)/.43)
  val(admin,(0,7.5,0));val(prop,(0,7.5,2.88))
  reach=Vector((-.75,-.7,-.7)).to_track_quat('-Z','Y').to_euler()
  val(aa[1],rot=tuple(a*u for a in reach),scale=(1,1,1+.35*u))
  val(O['BIG_RED_BUTTON'],loc=(0,0,1.36-.13*ease((t-52.4)/.13)))
 elif 52.85<=t<55.22:
  view((0,-11,9.8),(0,9,1.2),34)
 elif t>=55.22:
  b=bananas[0];u=ease((t-55.22)/1.8)
  view(mix((.2,-5.6,2.4),(-.4,-4.6,2.2),u),(-1.5,1,1.8),47)

 if t>=52.85:
  # Radial propagation reaches each existing avatar at its actual street position.
  radius=max(.001,(t-53.26)*14)
  val(wave,(0,6.8,.17),scale=(radius,radius,1) if 53.26<=t<55.15 else .001)
  for i,bn in enumerate(bananas):
   x,y=citizen_xy[i];distance=math.hypot(x,y-6.8);arrival=53.26+distance/14
   u=ease((t-arrival)/.19)
   z=1.45+abs(math.sin(t*10+i))*.12
   val(bn,(x,y,z),(0,.15*math.sin(t*8+i),.12*math.sin(t*6+i)),max(.001,u))
   if i==0:
    val(hero,(-1.5,1,.03),scale=max(.001,1-u));val(hat,(-1.5,1,2.88),scale=max(.001,1-u))
   elif 1<=i<=6:
    val(extras[i-1],(x,y,.03),rot=(0,0,0),scale=max(.001,.87*(1-u)))
    val(heads[i-1],(0,0,2.88),rot=(0,0,0),scale=1)
   elif i==7:
    val(admin,scale=max(.001,1-u));val(prop,(0,8,2.88),rot=(0,0,0),scale=max(.001,1-u))
  val(console,scale=1)
 if t>=55.22:
  # Confused double-take on the transformed protagonist, then a snap to camera.
  val(bananas[0],rot=(0,.28*math.sin((t-55.22)*8),.2*math.sin((t-55.22)*5)))
 # Record evaluated source motions plus the deliberate V3 overrides.
 for o in changed:
  for attr in tracks[o.name]:tracks[o.name][attr].append(tuple(getattr(o,attr)))
 lenses.append(cam.data.lens)
 if fr%300==0:print('V3_SAMPLED',fr,flush=True)

# Bulk curves are far faster and smaller than repeatedly inserting dense UI keys.
for o in changed:
 o.animation_data_clear();o.animation_data_create()
 a=bpy.data.actions.new(o.name+'_V3');o.animation_data.action=a
 for attr,values in tracks[o.name].items():
  for k in range(3):
   fc=a.fcurves.new(attr,index=k);fc.keyframe_points.add(END)
   fc.keyframe_points.foreach_set('co',[v for j,row in enumerate(values) for v in (j+1,row[k])])
   for p in fc.keyframe_points:p.interpolation='LINEAR'
   fc.update()
cam.data.animation_data_clear();cam.data.animation_data_create()
a=bpy.data.actions.new('V3_LENS');cam.data.animation_data.action=a
fc=a.fcurves.new('lens');fc.keyframe_points.add(END)
fc.keyframe_points.foreach_set('co',[v for j,x in enumerate(lenses) for v in (j+1,x)])
for p in fc.keyframe_points:p.interpolation='CONSTANT'
s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=6;s.cycles.use_denoising=True
s.render.threads_mode='FIXED';s.render.threads=5;s.render.use_persistent_data=True
s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100
s.render.fps=30;s.frame_start=1;s.frame_end=END
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB'
s.render.image_settings.compression=15
s.timeline_markers.clear()
for i,t in enumerate(cuts):s.timeline_markers.new(f'V3_CUT_{i:02d}',frame=round(t*30)+1)
s.frame_set(1);s.render.filepath=str(R/'frames_v3/frame_')
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Roblox_WhatIf_V3.blend'))
(R/'shot_cuts.json').write_text(json.dumps(cuts))
print('V3_UPGRADE_SAVED',flush=True)
