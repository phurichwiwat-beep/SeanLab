#!/usr/bin/env bash
set -euo pipefail
cd /workspace/SeanLab
uv python install 3.11.17
if [ ! -x .venv-blender/bin/python ]; then
  uv venv --python 3.11.17 .venv-blender
fi
uv pip install --python .venv-blender/bin/python --index-url https://pypi.org/simple \
  bpy==4.3.0 numpy==1.26.4 Pillow==12.3.0
OMP_NUM_THREADS=5 OPENBLAS_NUM_THREADS=1 .venv-blender/bin/python -c \
  'import bpy,numpy,PIL; assert bpy.app.version[:2] == (4,3); print("Blender",bpy.app.version_string,"NumPy",numpy.__version__,"Pillow",PIL.__version__)'
ffmpeg -hide_banner -filters 2>/dev/null | rg ' minterpolate '
ffmpeg -hide_banner -filters 2>/dev/null | rg ' ass '
ffmpeg -hide_banner -encoders 2>/dev/null | rg ' libx264 '
ffmpeg -hide_banner -encoders 2>/dev/null | rg ' aac '
